#include <stdio.h>
#include <sys/utsname.h>

// print the system information
void printSystemInfo();